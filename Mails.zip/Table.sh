        awk -F "," ' BEGIN {
                        print "From: arunkumar.vishwanathula@adp.com"
                        print "To: arunkumar.vishwanathula@adp.com"
                        print "MIME-Version: 1.0"
                        print "Content-Type: text/html"
                        print "Subject: Your Subject"
                        print "<html><body><table border=1 cellspacing=0 cellpadding=3>"
                        print "<tr>"
                        print "<th><b>SNO</b></th>"
                        print "<th><b>ExtractDetails</b></th>"
                        print "<td><b>Status</b></td>";
                        print "<td><b>Extracts_Location</b></td>";
                        print "</tr>"
                        } {
                        print "<tr>"
                        print "<td>"$1"</td>";
                        print "<td>"$2"</td>";
                        print "<td>"$3"</td>";
                        print "<td>"$4"</td>";
                        print "</tr>"
                        } END {
                        print "</table></body></html>"
                                                } ' Report.txt|/usr/sbin/sendmail -t
